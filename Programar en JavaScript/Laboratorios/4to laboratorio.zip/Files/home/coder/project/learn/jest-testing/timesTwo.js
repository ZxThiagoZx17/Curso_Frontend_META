// Task 1: Code the timesTwo function declaration
function timesTwo(number) {
    return number * 2;
}

// Exportar la función para poder usarla en los tests
module.exports = timesTwo;

// Task 2: Export the timesTwo function as a module
